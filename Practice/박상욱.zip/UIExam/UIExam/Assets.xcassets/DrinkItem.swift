//
//  DrinkItem.swift
//  UIExam
//
//  Created by 박소정 on 2018. 2. 7..
//  Copyright © 2018년 sangwook park. All rights reserved.
//

import UIKit

class DrinkItem: UIView {
    
}
